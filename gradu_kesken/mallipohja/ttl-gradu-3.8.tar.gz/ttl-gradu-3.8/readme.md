# Software you'll need:
* latex
* biber

# How to run it:
```
$ latex somefile.tex
$ biber somefile # if somefile.bib is your bibliography
$ latex somefile.tex
$ latex somefile.tex
```
